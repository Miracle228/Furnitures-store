package model;

import javax.swing.table.AbstractTableModel;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class ItemTableModel extends AbstractTableModel {
    String[] columnNames;
    Object[][] data;
    public  ItemTableModel(){
        columnNames = new String[] {"Brand", "Type", "Release date", "Price", "Made in", "Lenght", "widht","Weight", "Special signs"};



            ArrayList<Items> items = new ArrayList<>();

            DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd");

            try{
                Scanner input = new Scanner(new File("C:\\Users\\20669\\Desktop\\JavaApplication2\\src\\input.txt"));

                while(input.hasNextLine()){
                    String line;
                    Items items1 = new Items();

                    line = input.nextLine();

                    try{
                        Scanner data = new Scanner(line);
                        if(data.hasNext()){
                            String name = data.next().trim();
                            items1.setBrand(name);
                        }

                        if(data.hasNext()){
                            ItemType itemType = new ItemType();
                            itemType.setTypeName(data.next().trim());
                            items1.setItemType(itemType);
                        }

                        if(data.hasNext()){
                            LocalDate releaseDate = LocalDate.parse(data.next(), f);
                            items1.setReleaseDay(releaseDate);
                        }

                        if(data.hasNextInt()){
                            int price = data.nextInt();
                            items1.setPrice(price);
                        }

                        if(data.hasNext()){
                            String madeIn = data.next().trim();
                            items1.setMadeIn(madeIn);
                        }

                        if(data.hasNext()){
                            double weight = Double.parseDouble(data.next());
                            items1.setWeight(weight);
                        }
                        if(data.hasNext()){
                            double length = Double.parseDouble(data.next());
                            items1.setLenght(length);
                        }
                        if(data.hasNext()){
                            double widht = Double.parseDouble(data.next());
                            items1.setWidth(widht);
                        }

                        if(data.hasNext()){
                            String signs = data.next();
                            for(int i = 0; i < signs.split(",").length; i++){
                                items1.addSpecialSign(signs.split(",")[i]);
                            }
                        }

                    }catch(Exception e){
                        System.out.println(e);
                    }

                    items.add(items1);

                }

            }catch(IOException e){
                System.out.println(e);
            }

      

        data = new Object[items.size()][9];

        for (int i = 0; i < items.size(); i++) {

            data[i][0] = items.get(i).getBrand();
            data[i][1] = items.get(i).getItemType().getTypeName();
            data[i][2] = items.get(i).getReleaseDay().toString();
            data[i][3] = items.get(i).getPrice();
            data[i][4] = items.get(i).getMadeIn();
            data[i][5] = items.get(i).getLenght();
            data[i][6] = items.get(i).getWidht();
            data[i][7] = items.get(i).getWeight();
            data[i][8] = items.get(i).getSpecialSigns();

        }
    }

public void addItems(Items item){

        Object[][]  newData = new Object[data.length + 1][columnNames.length];

        for(int i = 0; i<data.length; i++){
            newData[i][0] = data[i][0];
            newData[i][1] = data[i][1];
            newData[i][2] = data[i][2];
            newData[i][3] = data[i][3];
            newData[i][4] = data[i][4];
            newData[i][5] = data[i][5];
            newData[i][6] = data[i][6];
            newData[i][7] = data[i][7];
            newData[i][8] = data[i][8];
        }

        newData[newData.length - 1 ][0] = item.getBrand();
        newData[newData.length - 1][1] = item.getItemType().getTypeName();
        newData[newData.length - 1][2] = item.getReleaseDay().toString();
        newData[newData.length - 1][3] = item.getPrice();
        newData[newData.length - 1][4] = item.getMadeIn();
        newData[newData.length - 1][5] = item.getLenght();
        newData[newData.length - 1][6] = item.getWeight();
        newData[newData.length - 1][7] = item.getWidht();
        newData[newData.length - 1][8] = item.getSpecialSigns();


        data = newData;

    }

   public void remItems(int rowID){
    	//System.out.println(rowID);
    	Object[][] newData = new Object[data.length-1][17];

    	int t = 0;
    	for(int i=0;i<data.length;i++){
    		if(i!=rowID){
	    		newData[t][0]=data[i][0];
	    		newData[t][1]=data[i][1];
	    		newData[t][2]=data[i][2];
                        newData[t][3]=data[i][3];
                        newData[t][4]=data[i][4];
                        newData[t][5]=data[i][5];
                        newData[t][6]=data[i][6];
                        newData[t][7]=data[i][7];
                        newData[t][8]=data[i][8];
	    		t++;
    		}
    	}
    	data = newData;
    }
   
   public void clearDB(File file){
   try {
       PrintWriter writer =new PrintWriter(file);
       writer.print("");
       writer.close();
   }
   catch(Exception e){
   System.out.println(e.toString());
   }
   }
   
   
   
   public boolean saveToDB(){
       
        try{
            File file = new File("C:\\Users\\20669\\Desktop\\JavaApplication2\\src\\input.txt");
            PrintWriter pw = new PrintWriter(new FileOutputStream(file, true));

            for(int i=0; i<data.length; i++){
                
                for(int j=0; j<data[0].length; j++){
                        pw.print(data[i][j]+ " ");
                }
                
                
                
                 pw.println();        
                 
            }
           
            pw.close();

        }catch(Exception e){

        }
        
   return false;
   }
   

    @Override
    public int getRowCount() {
        return data.length;
    }
    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }
    @Override
    public void setValueAt(Object value, int row, int col) {

        data[row][col] = value;
        fireTableCellUpdated(row, col);
    }
        


}

