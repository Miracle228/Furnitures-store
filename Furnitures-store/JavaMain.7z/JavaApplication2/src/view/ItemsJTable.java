package view;

import model.ItemTableModel;
import model.Items;
import model.ItemType;
import java.time.LocalDate;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableRowSorter;
import javax.swing.table.TableModel;
public class ItemsJTable extends JFrame {

    private ItemTableModel items;
    private JTable table;
    private TableRowSorter<TableModel> rowSorter;
    public ItemsJTable() {

        super("My furnitures store");

        items= new ItemTableModel();

        table = new JTable(items);

        JButton addButton = new JButton("Add item");
        
        addButton.addActionListener(
                new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                         String[] d4 = {"","",""};
             //         cities.addRow(d4);
             
                        String[] pic = {"","","","","","",""};
                        //JTable target = (JTable) e.getSource();
                        //int row = target.getSelectedRow();
                        //int column = target.getSelectedColumn();
                        //System.out.println(row+1);
//                        Items item = new Items();
//                        item.setBrand("Brand");
//                        item.setMadeIn("Made In");
//                        item.setReleaseDay(LocalDate.of(2015, 01, 10));
//                        item.setPrice(123);
//                        ItemType pts = new ItemType();
//                        pts.setTypeName("item Type");
//                        item.setItemType(pts);
//                        item.setWidth(200);
//                        item.setLenght(200.0);
//                        item.setWeight(200.0);
//                        item.addSpecialSign("cherni");
//                        items.addItems(item);
                            JInternalFrame editor = new JInternalFrame(
                                "Edit Record", true, true, true, true);
                        
                        GridLayout gridLayout = new GridLayout(0, 2);
                        gridLayout.setHgap(5);
                        gridLayout.setVgap(5);
                        
                        editor.setLayout(gridLayout);

                        editor.add(new JLabel(getColumnTitle(0)));
                        JTextField brand = new JTextField(20);
                        brand.setText("");
                        editor.add(brand);

                        editor.add(new JLabel(getColumnTitle(1)));
                        JTextField type1= new JTextField(20);
                        type1.setText(" ");
                        editor.add(type1);

                        editor.add(new JLabel(getColumnTitle(2)));
                        JTextField releaseDate = new JTextField(20);
                        releaseDate.setText(" ");
                        editor.add(releaseDate);
                        
                        
                        editor.add(new JLabel(getColumnTitle(3)));
                        JTextField price = new JTextField(20);
                        price.setText(" ");
                        editor.add(price);
                        
                        
                        editor.add(new JLabel(getColumnTitle(4)));
                        JTextField madeIn = new JTextField(20);
                        madeIn.setText(" ");
                        editor.add(madeIn);
                        
                        editor.add(new JLabel(getColumnTitle(5)));
                        JTextField lenght = new JTextField(20);
                        lenght.setText(" ");
                        editor.add(lenght);
                        
                        editor.add(new JLabel(getColumnTitle(6)));
                        JTextField width = new JTextField(20);
                        width.setText(" ");
                        editor.add(width);
                        
                        
                        editor.add(new JLabel(getColumnTitle(7)));
                        JTextField weight = new JTextField(20);
                        weight.setText(" ");
                        editor.add(weight);
                        
                        
                        editor.add(new JLabel(getColumnTitle(8)));
                        JTextField specialSigns = new JTextField(20);
                        specialSigns.setText(" ");
                        editor.add(specialSigns);
                                         
                        JButton saveButton = new JButton("Ok");
                        saveButton.addMouseListener(new MouseAdapter() {
                            public void mouseClicked(MouseEvent e) {

                                
                            	Items h1 = new Items();
                            	
                            	
                            	h1.setBrand(brand.getText());
                               
                                h1.setMadeIn(madeIn.getText());
                            	h1.setPrice(Integer.parseInt(price.getText()));
                                ItemType it =new ItemType();
                                it.setTypeName(type1.getText());
                               
                                h1.setItemType(it);
                                
                                h1.setWidth(Double.parseDouble(width.getText()));
                                h1.setLenght(Double.parseDouble(lenght.getText()));
                                h1.setWeight(Double.parseDouble(weight.getText()));
                                
                                h1.addSpecialSign(specialSigns.getText());
                            	
                            	
                            
                            

                            	
                            	((ItemTableModel)table.getModel()).addItems(h1);
                            	
                            	
                            	
                                JOptionPane.showMessageDialog(((JButton) e
                                        .getSource()).getParent(), "Record Saved!");
                            }
                        });
                        editor.add(saveButton);
                        
                        JButton cancelButton = new JButton("Cancel");
                        cancelButton.addMouseListener(new MouseAdapter() {
                            public void mouseClicked(MouseEvent e) {
                            	table.updateUI();
                                editor.hide();
                            }
                        });

                        editor.add(cancelButton);
                        
                        editor.pack();
                        table.add(editor);
                        editor.setVisible(true);
                        editor.setClosable(true);
             
                    

                        

                    }
                }
        );

        JButton removeButton = new JButton("Remove selected item");

        removeButton.addActionListener(
                new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {

                         
                         if(table.getSelectedRow()!= -1)
                    		((ItemTableModel)table.getModel()).remItems(table.getSelectedRow());
                    		table.updateUI();

                    }
                }
        );

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    JTable target = (JTable) e.getSource();
                    int row = target.getSelectedRow();
                    int column = target.getSelectedColumn();


                    JInternalFrame editorPopup = new JInternalFrame(
                            "Edit Record", true, true, true, true);

                    GridLayout gridLayout = new GridLayout(0, 2);
                    gridLayout.setHgap(5);
                    gridLayout.setVgap(5);

                    editorPopup.setLayout(gridLayout);

                    editorPopup.add(new JLabel(getColumnTitle(0)));
                    JTextField brand = new JTextField(20);
                    brand.setText(target.getValueAt(row, 0).toString());
                    editorPopup.add(brand);

                    editorPopup.add(new JLabel(getColumnTitle(1)));
                    JTextField type = new JTextField(20);
                    type.setText(target.getValueAt(row, 1).toString());
                    editorPopup.add(type);

                    editorPopup.add(new JLabel(getColumnTitle(2)));
                    JTextField releaseDate = new JTextField(20);
                    releaseDate.setText(target.getValueAt(row, 2).toString());
                    editorPopup.add(releaseDate);

                    editorPopup.add(new JLabel(getColumnTitle(3)));
                    JTextField price = new JTextField(20);
                    price.setText(target.getValueAt(row, 3).toString());
                    editorPopup.add(price);

                    editorPopup.add(new JLabel(getColumnTitle(4)));
                    JTextField madeIn = new JTextField(20);
                    madeIn.setText(target.getValueAt(row, 4).toString());
                    editorPopup.add(madeIn);

                    
                    editorPopup.add(new JLabel(getColumnTitle(5)));
                    JTextField lenght = new JTextField(20);
                    lenght.setText(target.getValueAt(row, 5).toString());
                    editorPopup.add(lenght);
                    
                    editorPopup.add(new JLabel(getColumnTitle(6)));
                    JTextField width = new JTextField(20);
                    width.setText(target.getValueAt(row, 6).toString());
                    editorPopup.add(width);
                    
                    
                    editorPopup.add(new JLabel(getColumnTitle(7)));
                    JTextField weight = new JTextField(20);
                    weight.setText(target.getValueAt(row, 7).toString());
                    editorPopup.add(weight);
                    
                                                                                           

                    editorPopup.add(new JLabel(getColumnTitle(8)));
                    JTextField specialSigns = new JTextField(20);
                    specialSigns.setText(target.getValueAt(row, 8).toString());
                    editorPopup.add(specialSigns);

                    JButton okButton = new JButton("Ok");
                    okButton.addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent e) {

                            table.getModel().setValueAt(brand.getText(), row, 0);
                            table.getModel().setValueAt(type.getText(), row, 1);
                            table.getModel().setValueAt(releaseDate.getText(), row, 2);
                            table.getModel().setValueAt(price.getText(), row, 3);
                            table.getModel().setValueAt(madeIn.getText(), row, 4);
                            table.getModel().setValueAt(lenght.getText(), row, 5);
                            table.getModel().setValueAt(width.getText(), row, 6);
                            table.getModel().setValueAt(weight.getText(), row, 7);
                            table.getModel().setValueAt(specialSigns.getText(), row, 8);

                            JOptionPane.showMessageDialog(((JButton) e
                                    .getSource()).getParent(), "Record Saved!");
                        }
                    });

                    editorPopup.add(okButton);

                    JButton cancelButton = new JButton("Cancel");
                    cancelButton.addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent e) {
                            editorPopup.hide();
                        }
                    });

                    editorPopup.add(cancelButton);

                    editorPopup.pack();

                    target.add(editorPopup);
                    editorPopup.setVisible(true);
                    editorPopup.setClosable(true);
                }

            }
        });

        table.setPreferredScrollableViewportSize(new Dimension(400, 400));
        table.setFillsViewportHeight(true);

        JPanel inputPanel = new JPanel();
        inputPanel.add(addButton);
        inputPanel.add(removeButton);

        
        Container container = getContentPane();
        container.add(new JScrollPane(table), BorderLayout.CENTER);
        container.add(inputPanel, BorderLayout.NORTH);
        
        JTextField jtfFilter = new JTextField();

        JButton jbtFilter = new JButton("Filter");
        JPanel panel = new JPanel(new BorderLayout());
        JButton search = new JButton("Search");
        panel.add(new JLabel("Specify a word to match:"),BorderLayout.WEST);
        panel.add(search, BorderLayout.EAST);
        panel.add(jtfFilter, BorderLayout.CENTER);
        container.add(panel, BorderLayout.SOUTH);
        rowSorter = new TableRowSorter<>(table.getModel());
        
        
        JButton saveToDB = new JButton("Save to db");
        panel.add(saveToDB,BorderLayout.BEFORE_FIRST_LINE);
        
       saveToDB.addActionListener(
                new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) { 
//                        System.out.print("hello world");
                        items.saveToDB();
                        
                        
                        
                        
                        
                        
                        ;

                    }
                }
        );
        
        
        
        
        
        table.setRowSorter(rowSorter);
         
        
        search.addActionListener(
                new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String text = jtfFilter.getText();
                        if(text.trim().length()==0){
                        rowSorter.setRowFilter(null);
                        }
                        else{
                        rowSorter.setRowFilter(RowFilter.regexFilter("(?i)"+jtfFilter.getText() ));
                        }
                    		
                         
                         
                         
                         
                         ;

                    }
                }
        );
        
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(400, 300);
        setVisible(true);
        
        
        
    }

    private String getColumnTitle(int index) {

        String title = null;

        switch (index) {
            case 0:
                title = "Brand";
                break;
            case 1:
                title = "Type";
                break;
            case 2:
                title = "release date";
                break;
            case 3:
                title = "price";
                break;
            case 4:
                title = "madeIn";
                break;
            case 5:
                title = "lenght";
                break;
            case 6:
                title = "Width";
                break;
            case 7:
                title = "Weight";
                break;

            case 8:
                title = "Special signs";
                break;
        }

        return title;
    }

}
