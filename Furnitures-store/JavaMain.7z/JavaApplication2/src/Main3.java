import view.ItemsJTable;
public class Main3 {
    public static void main(String args[]){

        new ItemsJTable();}
}
